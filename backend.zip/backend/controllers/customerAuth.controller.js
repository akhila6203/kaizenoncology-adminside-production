const crypto =
  require("crypto");

const bcrypt =
  require("bcryptjs");

const jwt =
  require("jsonwebtoken");

const Customer =
  require("../models/customer.model");
  
  const db = require("../config/db");

const CUSTOMER_COOKIE_NAME = "akeso_customer_session";

const customerCookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax",
  path: "/",
  maxAge: 7 * 24 * 60 * 60 * 1000,
};

const {
  sendActivationEmail,
  sendResetPasswordEmail,
} = require("../services/mail.service");


function createRawToken() {
  return crypto
    .randomBytes(32)
    .toString("hex");
}


function hashToken(token) {
  return crypto
    .createHash("sha256")
    .update(token)
    .digest("hex");
}


function expiresIn30Minutes() {
  return new Date(
    Date.now() + 30 * 60 * 1000
  );
}


function signCustomerToken(customer) {
  return jwt.sign(
    {
      id: customer.id,
      email: customer.email,
      type: "customer",
    },

    process.env.CUSTOMER_JWT_SECRET,

    {
      expiresIn:
        process.env
          .CUSTOMER_JWT_EXPIRES_IN ||
        "7d",
    }
  );
}


/* =========================================
   REGISTER
========================================= */

exports.register =
  async (req, res, next) => {

    try {

      const {
        name,
        email,
        phone,
      } = req.body;


      if (
        !name?.trim() ||
        !email?.trim() ||
        !phone?.trim()
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Name, email and mobile number are required.",
        });
      }


      const normalizedEmail =
        email.trim().toLowerCase();


      const existing =
        await Customer.findByEmail(
          normalizedEmail
        );


      if (
        existing &&
        existing.status === "active"
      ) {
        return res.status(409).json({
          success: false,
          message:
            "An account already exists with this email. Please login.",
        });
      }


      const rawToken =
        createRawToken();

      const tokenHash =
        hashToken(rawToken);

      // const expiresAt =
      //   expiresIn24Hours();
      const expiresAt =
  expiresIn30Minutes();


      let customerId;


      if (existing) {

        await Customer.refreshActivation({
          id: existing.id,
          name: name.trim(),
          phone: phone.trim(),
          tokenHash,
          expiresAt,
        });

        customerId =
          existing.id;

      } else {

        customerId =
          await Customer.createPending({
            name: name.trim(),
            email:
              normalizedEmail,
            phone: phone.trim(),
            tokenHash,
            expiresAt,
          });

      }


      await sendActivationEmail({
        name: name.trim(),
        email: normalizedEmail,
        token: rawToken,
      });


      return res.status(201).json({
        success: true,

        message:
          "Account created successfully. Please check your email to set your password.",

        customerId,
      });

    } catch (error) {
      next(error);
    }
  };


  
/* =========================================
   VALIDATE ACTIVATION TOKEN
========================================= */

exports.validateActivationToken = async (req, res, next) => {
  try {
    const { token } = req.body;

    if (typeof token !== "string" || !token.trim()) {
      return res.status(400).json({
        success: false,
        message: "Activation link is missing or invalid.",
      });
    }

    const customer = await Customer.findByActivationToken(
      hashToken(token.trim())
    );

    if (!customer || customer.status !== "pending") {
      return res.status(400).json({
        success: false,
        message:
          "This activation link has expired or has already been used.",
      });
    }

    return res.json({
      success: true,
      valid: true,
      message: "Activation link is valid.",
    });
  } catch (error) {
    next(error);
  }
};


/* =========================================
   SET PASSWORD
========================================= */

exports.setPassword =
  async (req, res, next) => {

    try {

      const {
        token,
        password,
      } = req.body;


      if (!token || !password) {
        return res.status(400).json({
          success: false,
          message:
            "Token and password are required.",
        });
      }


      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message:
            "Password must contain at least 6 characters.",
        });
      }


      const customer =
        await Customer.findByActivationToken(
          hashToken(token)
        );


      // if (!customer) {
      //   return res.status(400).json({
      //     success: false,
      //     message:
      //       "This activation link is invalid or has expired.",
      //   });
      // }
      if (!customer || customer.status !== "pending") {
  return res.status(400).json({
    success: false,
    message:
      "This activation link has expired or has already been used.",
  });
}


      const passwordHash =
        await bcrypt.hash(
          password,
          12
        );


      
const activated = await Customer.activate({
  id: customer.id,
  tokenHash: hashToken(token.trim()),
  password: passwordHash,
});

if (!activated) {
  return res.status(400).json({
    success: false,
    message:
      "This activation link has expired or has already been used.",
  });
}



      return res.json({
        success: true,

        message:
          "Password set successfully. You can now login.",
      });

    } catch (error) {
      next(error);
    }
  };


/* =========================================
   LOGIN
========================================= */
/* =========================================
   LOGIN - HTTP ONLY COOKIE
========================================= */

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required.",
      });
    }

    const customer = await Customer.findByEmail(
      email.trim().toLowerCase()
    );

    if (!customer) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password.",
      });
    }

    if (customer.status === "pending") {
      return res.status(403).json({
        success: false,
        message:
          "Please activate your account by setting your password from the email we sent you.",
      });
    }

    if (customer.status === "blocked") {
      return res.status(403).json({
        success: false,
        message:
          "Your account is currently unavailable.",
      });
    }

    if (!customer.password) {
      return res.status(403).json({
        success: false,
        message: "Please set your password first.",
      });
    }

    const valid = await bcrypt.compare(
      password,
      customer.password
    );

    if (!valid) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password.",
      });
    }

    const token = signCustomerToken(customer);

    await Customer.updateLastLogin(customer.id);

    // Store JWT in an HttpOnly cookie, not Local Storage.
    res.cookie(
      CUSTOMER_COOKIE_NAME,
      token,
      customerCookieOptions
    );

    return res.json({
      success: true,
      message: "Login successful.",

      // No token returned to frontend.
      user: {
        id: customer.id,
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
      },
    });

  } catch (error) {
    next(error);
  }
};



/* =========================================
   CHECK CUSTOMER SESSION
========================================= */

exports.session = async (req, res, next) => {
  try {
    const token = req.cookies?.[CUSTOMER_COOKIE_NAME];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Customer login required.",
      });
    }

    const payload = jwt.verify(
      token,
      process.env.CUSTOMER_JWT_SECRET
    );

    if (
      payload.type !== "customer" ||
      !Number.isInteger(Number(payload.id))
    ) {
      return res.status(401).json({
        success: false,
        message: "Invalid customer session.",
      });
    }

    const [[customer]] = await db.query(
      `SELECT id, name, email, phone, status
       FROM customers
       WHERE id = ? AND status = 'active'
       LIMIT 1`,
      [payload.id]
    );

    if (!customer) {
      res.clearCookie(
        CUSTOMER_COOKIE_NAME,
        customerCookieOptions
      );

      return res.status(401).json({
        success: false,
        message: "Customer account is inactive.",
      });
    }

    return res.json({
      success: true,
      user: {
        id: customer.id,
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
      },
    });

  } catch (error) {
    res.clearCookie(
      CUSTOMER_COOKIE_NAME,
      customerCookieOptions
    );

    return res.status(401).json({
      success: false,
      message: "Invalid or expired customer session.",
    });
  }
};


/* =========================================
   LOGOUT
========================================= */

exports.logout = (req, res) => {
  res.clearCookie(
    CUSTOMER_COOKIE_NAME,
    customerCookieOptions
  );

  return res.json({
    success: true,
    message: "Logged out successfully.",
  });
};

// exports.login =
//   async (req, res, next) => {

//     try {

//       const {
//         email,
//         password,
//       } = req.body;


//       if (!email || !password) {
//         return res.status(400).json({
//           success: false,
//           message:
//             "Email and password are required.",
//         });
//       }


//       const customer =
//         await Customer.findByEmail(
//           email.trim().toLowerCase()
//         );


//       if (!customer) {
//         return res.status(401).json({
//           success: false,
//           message:
//             "Invalid email or password.",
//         });
//       }


//       if (
//         customer.status ===
//         "pending"
//       ) {
//         return res.status(403).json({
//           success: false,
//           message:
//             "Please activate your account by setting your password from the email we sent you.",
//         });
//       }


//       if (
//         customer.status ===
//         "blocked"
//       ) {
//         return res.status(403).json({
//           success: false,
//           message:
//             "Your account is currently unavailable.",
//         });
//       }


//       if (!customer.password) {
//         return res.status(403).json({
//           success: false,
//           message:
//             "Please set your password first.",
//         });
//       }


//       const valid =
//         await bcrypt.compare(
//           password,
//           customer.password
//         );


//       if (!valid) {
//         return res.status(401).json({
//           success: false,
//           message:
//             "Invalid email or password.",
//         });
//       }


//       const token =
//         signCustomerToken(
//           customer
//         );


//       await Customer.updateLastLogin(
//         customer.id
//       );


//       return res.json({
//         success: true,

//         token,

//         user: {
//           id: customer.id,
//           name: customer.name,
//           email: customer.email,
//           phone: customer.phone,
//         },
//       });

//     } catch (error) {
//       next(error);
//     }
//   };


/* =========================================
   FORGOT PASSWORD
========================================= */

exports.forgotPassword =
  async (req, res, next) => {

    try {

      const { email } =
        req.body;


      if (!email?.trim()) {
        return res.status(400).json({
          success: false,
          message:
            "Email address is required.",
        });
      }


      const customer =
        await Customer.findByEmail(
          email
            .trim()
            .toLowerCase()
        );


      /*
        Don't reveal whether an
        email exists in database.
      */

      if (
        customer &&
        customer.status === "active"
      ) {

        const rawToken =
          createRawToken();

        await Customer.saveResetToken({
          id: customer.id,

          tokenHash:
            hashToken(rawToken),

          // expiresAt:
          //   expiresIn24Hours(),
          expiresAt:
  expiresIn30Minutes(),
        });


        await sendResetPasswordEmail({
          name: customer.name,
          email: customer.email,
          token: rawToken,
        });
      }


      return res.json({
        success: true,

        message:
          "If an account exists with this email, a password reset link has been sent.",
      });

    } catch (error) {
      next(error);
    }
  };


  exports.validateResetToken = async (req, res, next) => {
  try {
    const { token } = req.body;

    if (typeof token !== "string" || !token.trim()) {
      return res.status(400).json({
        success: false,
        message: "This link has expired or has already been used.",
      });
    }

    const customer = await Customer.findByResetToken(
      hashToken(token.trim())
    );

    if (!customer || customer.status !== "active") {
      return res.status(400).json({
        success: false,
        message: "This link has expired or has already been used.",
      });
    }

    return res.json({
      success: true,
      valid: true,
    });
  } catch (error) {
    next(error);
  }
};
/* =========================================
   RESET PASSWORD
========================================= */
exports.resetPassword =
  async (req, res, next) => {

    try {

      const {
        token,
        password,
      } = req.body;


      if (!token || !password) {
        return res.status(400).json({
          success: false,
          message:
            "Token and password are required.",
        });
      }


      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message:
            "Password must contain at least 6 characters.",
        });
      }


      const customer =
        await Customer.findByResetToken(
          hashToken(token)
        );


      if (!customer) {
        return res.status(400).json({
          success: false,
          message:
            "This password reset link is invalid or has expired.",
        });
      }


      const passwordHash =
        await bcrypt.hash(
          password,
          12
        );


     
const updated = await Customer.resetPassword({
  id: customer.id,
  tokenHash: hashToken(token.trim()),
  password: passwordHash,
});

if (!updated) {
  return res.status(400).json({
    success: false,
    message:
      "This password reset link has expired or has already been used.",
  });
}


      return res.json({
        success: true,

        message:
          "Password reset successfully. Please login with your new password.",
      });

    } catch (error) {
      next(error);
    }
  };